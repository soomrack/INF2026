#include "DHT.h"

short DHT_input_pin = 2;
#define DHTPIN DHT_input_pin
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);
float humidity;
short humidity_output_pin = 4;
float temperature;
short temperature_plus_output_pin = 5;
short temperature_minus_output_pin = 6;
short error_pin = 13;


const uint8_t lux_input_pin = A0;
short lux_output_pin = 3;
int analog_data_lux;
float lux;
float voltage;
float resistance;
const float GAMMA = 0.7;
const float RL10 = 50;


void setup() {
  dht.begin();
  pinMode(lux_output_pin, OUTPUT);
  pinMode(error_pin, OUTPUT);
  pinMode(humidity_output_pin, OUTPUT);
  pinMode(temperature_plus_output_pin, OUTPUT);
  pinMode(temperature_minus_output_pin, OUTPUT);
  pinMode(DHT_input_pin, INPUT);
}


void lux_check(){
  analog_data_lux = analogRead(lux_input_pin);
  voltage = analog_data_lux / 1024. * 5;
  resistance = 2000 * voltage / (1 - voltage / 5);
  lux = pow(RL10 * 1e3 * pow(10, GAMMA) / resistance, (1 / GAMMA));
  if (lux <= 3000){
    digitalWrite(lux_output_pin, 1);
    return;
  }
  digitalWrite(lux_output_pin, 0);
}


void humidity_check(){
  humidity = dht.readHumidity();
  if (humidity <= 40){
    digitalWrite(humidity_output_pin, 1);
    return;
  }
  digitalWrite(humidity_output_pin, 0);
}


void temperature_check(){
  temperature = dht.readTemperature();

  if (temperature <= 15){
    digitalWrite(temperature_plus_output_pin, 1);
    return;
  }
  else if (temperature >= 50){
    digitalWrite(temperature_minus_output_pin, 1);
    return;
  }
  digitalWrite(temperature_plus_output_pin, 0);
  digitalWrite(temperature_minus_output_pin, 0);
}


void error_dht_check(){
  if (isnan(humidity) || isnan(temperature)){
    digitalWrite(error_pin, 1);
  }
}

void loop() {
  lux_check();
  humidity_check();
  temperature_check();
  error_check();
}
